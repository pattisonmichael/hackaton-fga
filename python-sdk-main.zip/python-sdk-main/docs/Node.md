# Node


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**leaf** | [**Leaf**](Leaf.md) |  | [optional] 
**difference** | [**UsersetTreeDifference**](UsersetTreeDifference.md) |  | [optional] 
**union** | [**Nodes**](Nodes.md) |  | [optional] 
**intersection** | [**Nodes**](Nodes.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


