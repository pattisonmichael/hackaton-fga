# Nodes


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nodes** | [**list[Node]**](Node.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


