# ReadAssertionsResponse


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authorization_model_id** | **str** |  | [optional] 
**assertions** | [**list[Assertion]**](Assertion.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


