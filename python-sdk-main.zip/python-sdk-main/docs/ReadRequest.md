# ReadRequest


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tuple_key** | [**TupleKey**](TupleKey.md) |  | [optional] 
**page_size** | **int** |  | [optional] 
**continuation_token** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


