# ReadResponse


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tuples** | [**list[Tuple]**](Tuple.md) |  | [optional] 
**continuation_token** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


