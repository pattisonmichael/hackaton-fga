# Tuple


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | [**TupleKey**](TupleKey.md) |  | [optional] 
**timestamp** | **datetime** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


