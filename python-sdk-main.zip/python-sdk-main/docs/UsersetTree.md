# UsersetTree

A UsersetTree contains the result of an Expansion.

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**root** | [**Node**](Node.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


